import { useCallback, useEffect, useState } from "react";
import { supabase } from "../lib/supabase.ts";

export type AcademyAccessStatus = "loading" | "anonymous" | "inactive" | "active" | "unavailable";

type EntitlementRow = {
  access_status: string | null;
  expires_at: string | null;
};

function isCurrentlyActive(row: EntitlementRow | null): boolean {
  if (!row || row.access_status !== "active") return false;
  if (!row.expires_at) return true;
  return new Date(row.expires_at).getTime() > Date.now();
}

/**
 * Paid access is intentionally database-backed. There is no localStorage or
 * client-side "premium" switch. Until the entitlement table is installed,
 * the Academy remains safely in preview mode.
 */
export function useAcademyAccess() {
  const [status, setStatus] = useState<AcademyAccessStatus>("loading");
  const [isMember, setIsMember] = useState(false);

  const reload = useCallback(async () => {
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      setIsMember(false);
      setStatus("anonymous");
      return;
    }

    const { data, error } = await supabase
      .from("academy_entitlements")
      .select("access_status, expires_at")
      .eq("user_id", user.id)
      .eq("product", "curio_ai_ml_academy")
      .maybeSingle();

    if (error) {
      // The frontend must fail closed. A missing migration or network issue
      // must never accidentally unlock paid lessons.
      setIsMember(false);
      setStatus("unavailable");
      return;
    }

    const active = isCurrentlyActive((data ?? null) as EntitlementRow | null);
    setIsMember(active);
    setStatus(active ? "active" : "inactive");
  }, []);

  useEffect(() => { void reload(); }, [reload]);

  return { isMember, status, loading: status === "loading", reload };
}
