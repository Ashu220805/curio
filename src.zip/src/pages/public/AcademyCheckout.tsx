import { Link } from "react-router-dom";
import { useDocumentMeta } from "../../hooks/useDocumentMeta.ts";
import { useAuth } from "../../hooks/useAuth.ts";
import { useAcademyAccess } from "../../hooks/useAcademyAccess.ts";
import "./Academy.css";

export default function AcademyCheckout() {
  useDocumentMeta("CURIO Academy Membership", "CURIO Academy membership architecture and the requirements for a secure production payment flow.");
  const { user, loading: authLoading } = useAuth();
  const { isMember, status } = useAcademyAccess();

  return <main className="checkout-page">
    <header className="academy-topbar">
      <Link to="/academy" className="academy-brand"><img src="/curio-symbol.png" alt="CURIO" /><span>CURIO</span><small>AI / ML ACADEMY</small></Link>
      <nav><Link to="/academy">Back to academy</Link>{user ? <Link to="/dashboard">Dashboard</Link> : <Link to="/login">Sign in</Link>}</nav>
    </header>

    <section className="checkout-hero">
      <div>
        <span className="academy-kicker">ACADEMY MEMBERSHIP</span>
        <h1>Build the membership system first. Then accept payments safely.</h1>
        <p>The learning product is ready to support paid access, but payment success must be verified on the server before a CURIO account is unlocked.</p>
      </div>
      <article>
        <span>MEMBERSHIP STATUS</span>
        <strong>{authLoading ? "Checking account" : isMember ? "Academy member" : user ? "Membership not active" : "Sign in required"}</strong>
        <p>{isMember ? "Your Academy access is active from the Supabase entitlement check." : "The production checkout is intentionally not simulated. CURIO will not mark a user as paid from a frontend button, URL parameter or browser storage."}</p>
        <ul>
          <li>45 structured lessons in serial order</li>
          <li>Regression families and evaluation</li>
          <li>Neural networks, activations and backpropagation</li>
          <li>Feature engineering, LLMs, MLOps and capstone skills</li>
        </ul>
        {isMember ? <Link className="checkout-primary" to="/academy">Open Academy</Link> : !user ? <Link className="checkout-primary" to="/login">Sign in to continue</Link> : <div className="checkout-setup"><strong>Payment backend is the next production step</strong><p>Current access check: {status}. Connect a provider Checkout Session and a signed webhook before enabling a live purchase button.</p></div>}
      </article>
    </section>

    <section className="checkout-security">
      <div><span className="section-label">PRODUCTION PAYMENT FLOW</span><h2>Who paid, what they bought, and why access is active should be server-backed.</h2></div>
      <div className="security-grid">
        <article><strong>Supabase Auth</strong><p>Every purchaser has a verified CURIO user ID. Authentication is separate from Academy authorization.</p></article>
        <article><strong>Checkout Session</strong><p>A server-side function creates the payment session and attaches the CURIO user ID and product identifier.</p></article>
        <article><strong>Signed webhook</strong><p>The payment provider confirms success to a trusted endpoint. The browser never decides that payment succeeded.</p></article>
        <article><strong>academy_entitlements</strong><p>The webhook records active access. The Academy reads this server-backed entitlement and fails closed on errors.</p></article>
      </div>
    </section>
  </main>;
}
