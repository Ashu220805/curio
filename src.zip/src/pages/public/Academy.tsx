import { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  academyLessons,
  academyModules,
  type AcademyLesson,
  type LessonDiagram,
} from "../../data/academy.ts";
import { useAcademyAccess } from "../../hooks/useAcademyAccess.ts";
import { useDocumentMeta } from "../../hooks/useDocumentMeta.ts";
import "./Academy.css";

const PROGRESS_KEY = "curio_academy_progress_v3";
const FREE_PREVIEW_LESSONS = 3;

type View = "lesson" | "map" | "practice" | "review";

function readProgress(): number[] {
  try {
    const value = localStorage.getItem(PROGRESS_KEY);
    const parsed: unknown = value ? JSON.parse(value) : [];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item): item is number => Number.isInteger(item));
  } catch {
    return [];
  }
}

function saveProgress(values: number[]) {
  try {
    const unique = [...new Set(values)].sort((a, b) => a - b);
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(unique));
  } catch {
    // Progress storage is a convenience. Access control never depends on it.
  }
}

function Diagram({ kind, nodes }: { kind: LessonDiagram; nodes: string[] }) {
  const safe = nodes.slice(0, 9);
  if (kind === "neural") return <div className="academy-visual neural-visual" aria-label="Neural network concept diagram"><div className="nn-col"><span>Input</span><i /><i /><i /></div><b>→</b><div className="nn-col"><span>Hidden</span><i /><i /><i /><i /></div><b>→</b><div className="nn-col"><span>Output</span><i /><i /></div></div>;
  if (kind === "regression") return <div className="academy-visual regression-visual" aria-label="Regression concept diagram"><div className="reg-axis" /><div className="reg-line" /><div className="reg-dot d1" /><div className="reg-dot d2" /><div className="reg-dot d3" /><div className="reg-dot d4" /><span>features X → prediction ŷ → error</span></div>;
  if (kind === "tree") return <div className="academy-visual tree-visual" aria-label="Decision tree diagram"><div className="tree-node root">Feature split</div><div className="tree-lines"><i /><i /></div><div className="tree-row"><div><span className="tree-node">Rule A</span><small>Leaf / prediction</small></div><div><span className="tree-node">Rule B</span><small>Leaf / prediction</small></div></div></div>;
  if (kind === "transformer") return <div className="academy-visual transformer-visual" aria-label="Transformer flow diagram"><span>Tokens</span><b>→</b><span>Embeddings</span><b>→</b><span>Q · K · V</span><b>→</b><span>Attention</span><b>→</b><span>Output</span></div>;
  if (kind === "mlops") return <div className="academy-visual loop-visual" aria-label="MLOps lifecycle"><span>Data</span><b>→</b><span>Train</span><b>→</b><span>Evaluate</span><b>→</b><span>Deploy</span><b>→</b><span>Monitor</span><b>↺</b></div>;
  return <div className="academy-visual flow-visual" aria-label="Learning flow">{safe.map((node, index) => <div key={`${node}-${index}`}><span>{node}</span>{index < safe.length - 1 && <b>→</b>}</div>)}</div>;
}

function MindMap({ lesson }: { lesson: AcademyLesson }) {
  return <div className="academy-mindmap" aria-label={`${lesson.title} mind map`}><div className="mind-core">{lesson.title}</div>{lesson.mindMap.slice(0, 8).map((item, index) => <div key={item} className={`mind-node mind-${index + 1}`}><i />{item}</div>)}</div>;
}

function CodeStudy({ lesson }: { lesson: AcademyLesson }) {
  const [copied, setCopied] = useState(false);
  if (!lesson.code) return null;
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(lesson.code?.code ?? "");
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      setCopied(false);
    }
  };
  return <section className="academy-code-study"><div className="section-label-row"><div><span className="section-label">CODE WALKTHROUGH</span><h3>Read the pattern before changing it.</h3></div><button type="button" onClick={copy}>{copied ? "Copied" : "Copy code"}</button></div><pre><code>{lesson.code.code}</code></pre><ol>{lesson.code.notes.map((note) => <li key={note}>{note}</li>)}</ol></section>;
}

export default function Academy() {
  useDocumentMeta("CURIO AI / ML Academy", "A serial AI and machine learning curriculum from Python foundations through neural networks, LLMs, production systems and research skills.");
  const [searchParams] = useSearchParams();
  const requestedLesson = Number(searchParams.get("lesson"));
  const initialOrder = Number.isInteger(requestedLesson) && requestedLesson >= 1 && requestedLesson <= academyLessons.length ? requestedLesson : 1;
  const [selectedOrder, setSelectedOrder] = useState(initialOrder);
  const [view, setView] = useState<View>("lesson");
  const [completed, setCompleted] = useState<number[]>(readProgress);
  const [query, setQuery] = useState("");
  const { isMember, status, loading: accessLoading } = useAcademyAccess();

  useEffect(() => {
    if (requestedLesson >= 1 && requestedLesson <= academyLessons.length) setSelectedOrder(requestedLesson);
  }, [requestedLesson]);

  useEffect(() => { saveProgress(completed); }, [completed]);

  const lesson = academyLessons.find((item) => item.order === selectedOrder) ?? academyLessons[0];
  const completedCount = completed.length;
  const progress = Math.round((completedCount / academyLessons.length) * 100);
  const previewUnlocked = Math.min(FREE_PREVIEW_LESSONS, Math.max(1, completed.filter((order) => order <= FREE_PREVIEW_LESSONS).length + 1));
  const highestUnlocked = isMember ? academyLessons.length : previewUnlocked;
  const practiceUnlocked = completed.includes(lesson.order) && (isMember || lesson.order <= FREE_PREVIEW_LESSONS);

  const filteredModules = useMemo(() => academyModules.map((module) => ({
    ...module,
    lessons: module.lessons.filter((item) => `${item.order} ${item.title} ${item.summary} ${item.module} ${item.concepts.map((concept) => concept.term).join(" ")}`.toLowerCase().includes(query.toLowerCase())),
  })).filter((module) => module.lessons.length > 0), [query]);

  const selectLesson = (next: AcademyLesson) => {
    if (!isMember && next.order > highestUnlocked) return;
    setSelectedOrder(next.order);
    setView("lesson");
    window.setTimeout(() => document.querySelector(".academy-content")?.scrollTo({ top: 0, behavior: "smooth" }), 0);
  };

  const completeLesson = () => setCompleted((current) => current.includes(lesson.order) ? current : [...current, lesson.order]);

  const move = (delta: number) => {
    const target = academyLessons.find((item) => item.order === lesson.order + delta);
    if (target && (isMember || target.order <= highestUnlocked)) selectLesson(target);
  };

  const accessLabel = accessLoading ? "Checking membership" : isMember ? "Academy member" : status === "anonymous" ? "Preview access" : status === "unavailable" ? "Membership setup pending" : "Preview access";

  return <main className="academy-shell">
    <header className="academy-topbar">
      <Link to="/academy" className="academy-brand"><img src="/curio-symbol.png" alt="CURIO" /><span>CURIO</span><small>AI / ML ACADEMY</small></Link>
      <div className="academy-top-progress" aria-label={`${completedCount} of ${academyLessons.length} lessons completed`}><span>{completedCount} / {academyLessons.length} completed</span><div><i style={{ width: `${progress}%` }} /></div></div>
      <nav><Link to="/dashboard">Dashboard</Link><span className="academy-member-chip">{accessLabel}</span>{!isMember && <Link className="academy-upgrade-link" to="/academy/checkout">Membership</Link>}</nav>
    </header>

    <section className="academy-intro">
      <div className="academy-intro-copy"><span className="academy-kicker">A SERIAL CURRICULUM FOR AIML AND ENGINEERING STUDENTS</span><h1>Build AI knowledge in the order the ideas depend on each other.</h1><p>CURIO keeps the academy inside one connected learning environment. Start with computation and Python, then mathematics and data, machine learning, feature engineering, neural networks, language models, generative systems, production engineering and research practice.</p><div className="academy-intro-points"><span>Concept → explanation → diagram → code → common errors → practice</span><span>No random topic jumping</span><span>Practice unlocks after learning</span></div></div>
      <div className="academy-roadmap-card"><span className="section-label">YOUR LEARNING PATH</span><div className="roadmap-orbit"><div className="roadmap-core"><img src="/curio-symbol.png" alt="" />CURIO</div><span>Python</span><span>Math</span><span>ML</span><span>Neural nets</span><span>LLMs</span><span>Systems</span></div></div>
    </section>

    {!isMember && <section className="academy-preview-notice" aria-live="polite"><strong>Preview: lessons 1–{FREE_PREVIEW_LESSONS} are available.</strong><span>Membership access will be verified by Supabase after the production payment webhook is connected. There is no browser-side premium switch.</span><Link to="/academy/checkout">View membership</Link></section>}

    <div className="academy-workspace">
      <aside className="academy-curriculum" aria-label="Academy curriculum">
        <div className="curriculum-head"><span className="section-label">CURRICULUM</span><strong>{academyModules.length} modules · {academyLessons.length} lessons</strong><label><span>Search lessons</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Python, regression, attention..." /></label></div>
        <div className="curriculum-list">{filteredModules.map((module) => <section key={module.id} className="curriculum-module"><div className="module-title"><span>{module.number}</span><div><strong>{module.title}</strong><small>{module.description}</small></div></div>{module.lessons.map((item) => { const locked = !isMember && item.order > highestUnlocked; const done = completed.includes(item.order); return <button key={item.id} type="button" onClick={() => selectLesson(item)} className={`curriculum-lesson ${selectedOrder === item.order ? "is-active" : ""} ${locked ? "is-locked" : ""}`} disabled={locked} aria-current={selectedOrder === item.order ? "page" : undefined}><span className="lesson-state">{done ? "Done" : locked ? "Locked" : String(item.order).padStart(2, "0")}</span><div><strong>{item.title}</strong><small>{item.level} · {item.duration}</small></div></button>; })}</section>)}</div>
      </aside>

      <section className="academy-content">
        <div className="lesson-crumb"><span>{lesson.module}</span><span>Lesson {String(lesson.order).padStart(2, "0")}</span><span>{lesson.level}</span></div>
        <article className="lesson-hero-card"><div><span className="academy-kicker">CURRENT LESSON</span><h2>{lesson.title}</h2><p>{lesson.summary}</p><div className="lesson-actions"><button type="button" onClick={() => setView("lesson")} className={view === "lesson" ? "is-current" : ""}>Learn</button><button type="button" onClick={() => setView("map")} className={view === "map" ? "is-current" : ""}>Mind map</button><button type="button" onClick={() => setView("review")} className={view === "review" ? "is-current" : ""}>Recall</button><button type="button" disabled={!practiceUnlocked} onClick={() => setView("practice")} className={view === "practice" ? "is-current" : ""}>Practice {practiceUnlocked ? "" : "Locked"}</button></div></div><div className="lesson-status"><span>{completed.includes(lesson.order) ? "Completed" : "In progress"}</span><strong>{lesson.duration}</strong></div></article>

        {view === "lesson" && <div className="lesson-view"><section className="lesson-why"><span className="section-label">WHY THIS LESSON MATTERS</span><p>{lesson.why}</p></section><section className="lesson-objectives"><span className="section-label">BY THE END, YOU SHOULD BE ABLE TO</span>{lesson.objectives.map((objective) => <div key={objective}>{objective}</div>)}</section><Diagram kind={lesson.diagram} nodes={lesson.mindMap} /><section className="concept-definition-grid"><div className="section-title"><span className="section-label">CORE DEFINITIONS</span><h3>Understand the words before memorizing the code.</h3></div>{lesson.concepts.map((concept) => <article key={concept.term}><strong>{concept.term}</strong><p>{concept.definition}</p></article>)}</section><CodeStudy lesson={lesson} /><section className="lesson-errors"><span className="section-label">COMMON ERRORS AND MISCONCEPTIONS</span>{lesson.commonErrors.map((error, index) => <div key={error}><b>{String(index + 1).padStart(2, "0")}</b><p>{error}</p></div>)}</section><section className="lesson-complete-card"><div><span className="section-label">LEARNING CHECKPOINT</span><h3>Do not complete by scrolling. Complete when you can explain the idea without copying the page.</h3></div><button type="button" onClick={completeLesson}>{completed.includes(lesson.order) ? "Lesson completed" : "Mark lesson complete"}</button></section></div>}
        {view === "map" && <section className="mindmap-view"><div className="section-title"><span className="section-label">VISIBLE MIND MAP</span><h3>Read the concept connections without overlapping cards.</h3><p>The central lesson stays fixed while connected ideas move into a responsive grid on smaller screens.</p></div><MindMap lesson={lesson} /><div className="mindmap-key">{lesson.mindMap.map((item, index) => <span key={item}><b>{String(index + 1).padStart(2, "0")}</b>{item}</span>)}</div></section>}
        {view === "review" && <section className="recall-view"><span className="section-label">ACTIVE RECALL</span><h3>Answer these prompts in your own words before revealing the explanation.</h3>{lesson.concepts.map((concept, index) => <details key={concept.term}><summary>{String(index + 1).padStart(2, "0")}. Define {concept.term} without looking.</summary><p>{concept.definition}</p></details>)}<button type="button" onClick={completeLesson}>{completed.includes(lesson.order) ? "Recall saved" : "I can explain this lesson"}</button></section>}
        {view === "practice" && <section className="practice-view"><span className="section-label">PRACTICE AREA · UNLOCKED BY PROGRESS</span><h3>{lesson.practice.prompt}</h3><textarea placeholder="Write your reasoning here. Explain the steps, not only the final answer." rows={10} /><div className="practice-checkpoints"><span>Self-check before continuing</span>{lesson.practice.checkpoints.map((checkpoint) => <label key={checkpoint}><input type="checkbox" /> {checkpoint}</label>)}</div><button type="button" onClick={completeLesson}>Save learning checkpoint</button></section>}
        <footer className="academy-lesson-footer"><button type="button" disabled={lesson.order === 1} onClick={() => move(-1)}>Previous lesson</button><span>Lesson {lesson.order} of {academyLessons.length}</span><button type="button" disabled={lesson.order >= highestUnlocked || lesson.order === academyLessons.length} onClick={() => move(1)}>Next lesson</button></footer>
      </section>
    </div>

    {!isMember && <section className="academy-premium-strip"><div><span className="section-label">CURIO ACADEMY MEMBERSHIP</span><h2>One structured academy. Full depth. No scattered learning path.</h2><p>Membership unlocks the complete serial curriculum and practice checkpoints. Real payment activation must be confirmed by a signed provider webhook and written to Supabase. Until that backend is connected, no payment button can grant access.</p></div><div><Link to="/academy/checkout">View membership setup</Link></div></section>}
  </main>;
}
